package com.vgnarray.hanumanchalisa;

import com.vgnarray.hanumanchalisa.CustomFab;

/**
 * Created by Vinay on 22-10-2015.
 */
public interface PlaySongIntface {
    public void playCurr(CustomFab songobj, boolean bool);


}
